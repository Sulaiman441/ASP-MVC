﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Owin;
using Newtonsoft.Json.Serialization;
using Owin;

[assembly: OwinStartup(typeof(mvc_odata_v3.Startup))]

namespace mvc_odata_v3
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
         
            ConfigureAuth(app);
           
        }
    }
}
