namespace mvc_odata_v3.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using mvc_odata_v3.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<mvc_odata_v3.Models.mvc_odata_v3Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(mvc_odata_v3.Models.mvc_odata_v3Context context)
        {
            context.Products.AddOrUpdate(new Product[] {
        new Product() { ID = 1, Name = "Hat", Price = 15, Category = "Apparel", Author=true },
        new Product() { ID = 2, Name = "Socks", Price = 5, Category = "Apparel", Author=true },
        new Product() { ID = 3, Name = "Scarf", Price = 12, Category = "Apparel" , Author=false },
        new Product() { ID = 4, Name = "Yo-yo", Price = 4.95M, Category = "Toys", Author=false  },
        new Product() { ID = 5, Name = "Puzzle", Price = 8, Category = "Toys" , Author=false },
    });
        }
    }
}
