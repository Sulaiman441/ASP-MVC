﻿using System;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EJGrid.Controllers
{
    public class EmployeesController : ODataController
    {
        public static List<Employees> emp = new List<Employees>();
        [EnableQuery]
        public IQueryable<Employees> Get()
        {
            if (emp.Count == 0)
                ForeignData();
            return emp.AsQueryable();
        }
        public void ForeignData()
        {
            int code = 10000;
            for (int i = 0; i < 1; i++)
            {
                emp.Add(new Employees(code + 0, "Value" + "Berlin", @"""Andrew""" + i));
                emp.Add(new Employees(code + 2, "valu2'", @"""Nancy""" + i));
                emp.Add(new Employees(code + 1, @"""value3""", @"""Jarget""" + i));
                emp.Add(new Employees(code + 3, @"""value4""", @"""Margrey""" + i));
                emp.Add(new Employees(code + 4, @"""value5""", @"""doublequotes""" + i));
                code += 5;
            }
        }
        public class Employees
        {
            public Employees()
            {

            }
            public Employees(int EmployeeID, string FirstName, string LastName)
            {
                this.EmployeeID = EmployeeID;
                this.FirstName = FirstName;
                this.LastName = LastName;
            }
            [Key]
            public int EmployeeID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
    }
}
