﻿using EJGrid.Models;
using Microsoft.OData.Core.UriParser;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.OData;
using System.Web.OData.Query;

namespace EJGrid.Controllers
{
    public class OrdersController : ODataController
    {
        public static List<Orders> order = new List<Orders>();
        // GET: Orders
        [EnableQuery]
        public IQueryable<Orders> Get()
        {
            if (order.Count == 0)
                BindDataSource();
            return order.AsQueryable();
        }
        public HttpResponseMessage Patch([FromODataUri]int key, [FromBody]Orders entity)
        {
            Orders data = order.Where(p => p.OrderID == key).FirstOrDefault();
            if (data != null)
            {
                data.OrderID = entity.OrderID;
                data.CustomerID = entity.CustomerID;
                data.Freight = entity.Freight;
                data.EmployeeID = entity.EmployeeID;
                data.ShipCity = entity.ShipCity;
            }
            else
            {
                Request.CreateResponse(HttpStatusCode.NotFound);
            }
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
        public HttpResponseMessage Post(Orders value)
        {
            order.Add(value);
            return Request.CreateResponse(HttpStatusCode.OK, value);
        }

        public HttpResponseMessage Delete([FromODataUri]int key)
        {
            Orders data = order.Where(p => p.OrderID == key).FirstOrDefault();
            if (data != null)
            {
                order.Remove(data);
            }
            else
            {
                Request.CreateResponse(HttpStatusCode.NotFound);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Removed");
        }
        private void BindDataSource()
        {
            int code = 10000;
            for (int i = 0; i < 1; i++)
            {
                order.Add(new Orders(code + 1, "ALFKI", code + 0, 2.3 * i, new DateTime(1991, 05, 15), "Berlin", @"""Andrew""" + i));
                order.Add(new Orders(code + 2, "ANATR", code + 2, 3.3 * i, new DateTime(1990, 04, 04), "Madrid", @"""Nancy""" + i));
                order.Add(new Orders(code + 3, "ANTON", code + 1, 4.3 * i, new DateTime(1957, 11, 30), "Cholchester", @"""Jarget""" + i));
                order.Add(new Orders(code + 4, "BLONP", code + 3, 5.3 * i, new DateTime(1930, 10, 22), "Marseille", @"""Margrey""" + i));
                order.Add(new Orders(code + 5, "BOLID", code + 4, 6.3 * i, new DateTime(1953, 02, 18), "Tsawassen", @"""doublequotes""" + i));
                code += 5;
            }

        }
        public class Orders
        {
            public Orders()
            {

            }
            public Orders(long OrderId, string CustomerId, int EmployeeId, double Freight, DateTime? OrderDate, string ShipCity, string ID)
            {
                this.OrderID = OrderId;
                this.CustomerID = CustomerId;
                this.EmployeeID = EmployeeId;
                this.Freight = Freight;
                this.OrderDate = OrderDate;
                this.ShipCity = ShipCity;
                this.ID = ID;
            }
            [Key]
            public long OrderID { get; set; }
            public string CustomerID { get; set; }
            public int EmployeeID { get; set; }
            public double Freight { get; set; }
            public DateTime? OrderDate { get; set; }
            public string ShipCity { get; set; }

            public string ID { get; set; }
        }
    }
}