﻿using EJGrid.Models;
using Microsoft.OData.Core.UriParser;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.OData;
using System.Web.OData.Query;

namespace EJGrid.Controllers
{
    public class OrdersController : ODataController
    {
        public static List<Orders> order = new List<Orders>();
        // GET: Orders
        [EnableQuery]
        public IQueryable<Orders> Get()
        {
            if (order.Count == 0)
                BindDataSource();
            return order.AsQueryable();
        }
        public Orders Patch([FromODataUri]int key, [FromBody]Delta<Orders> patch)
        {
            Orders data = order.Where(p => p.OrderID == key).FirstOrDefault();
            patch.Patch(data);
            return data;
        }
        public HttpResponseMessage Post(Orders value)
        {
            order.Add(value);
            return Request.CreateResponse(HttpStatusCode.OK, value);
        }

        public HttpResponseMessage Delete([FromODataUri]int key)
        {
            Orders data = order.Where(p => p.OrderID == key).FirstOrDefault();
            if (data != null)
            {
                order.Remove(data);
            }
            else
            {
                Request.CreateResponse(HttpStatusCode.NotFound);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Removed");
        }
        private void BindDataSource()
        {
            order.Add(new Orders(10248, "ALFKI", 1, 2.3, "Berlin"));
            order.Add(new Orders(10249, "ANATR", 2, 3.3, "Madrid"));
            order.Add(new Orders(10250, "ANTON", 3, 4.3, "Cholchester"));
            order.Add(new Orders(10251, "BLONP", 4, 5.3, "Marseille"));
            order.Add(new Orders(10252, "BOLID", 5, 6.3, "Tsawassen"));
        }
        public class Orders
        {
            public Orders()
            {

            }
            public Orders(long OrderId, string CustomerId, int EmployeeId, double Freight, string ShipCity)
            {
                this.OrderID = OrderId;
                this.CustomerID = CustomerId;
                this.EmployeeID = EmployeeId;
                this.Freight = Freight;
                this.ShipCity = ShipCity;
            }
            [Key]
            public long OrderID { get; set; }
            public string CustomerID { get; set; }
            public int EmployeeID { get; set; }
            public double Freight { get; set; }
            public string ShipCity { get; set; }
        }
    }
}