﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using WebApplication61.Models;


namespace WebApplication61.Controllers
{

    public class OrderController : ApiController
    {
        // GET: api/Order
        public object Get()
        {
            
            var queryString = System.Web.HttpContext.Current.Request.QueryString;
            int skip = Convert.ToInt32(queryString["$skip"]); //paging
            int take = Convert.ToInt32(queryString["$top"]);
            string filter = queryString["$filter"]; // filtering 
            string sort = queryString["$orderby"]; // sorting 
            var data = OrdersDetails.GetAllRecords();
            List<OrdersDetails> Datae = new List<OrdersDetails>();
            List<OrdersDetails> Datase = new List<OrdersDetails>();
            if (sort != null) //Sorting
            {
                switch (sort)
                {
                    case "OrderID":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.OrderID).ToList();
                        else
                            data = data.OrderBy(x => x.OrderID).ToList();
                        break;
                    case "CustomerID":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.CustomerID).ToList();
                        else
                            data = data.OrderBy(x => x.CustomerID).ToList();
                        break;
                    case "ShipCity":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.ShipCity).ToList();
                        else
                            data = data.OrderBy(x => x.ShipCity).ToList();
                        break;
                    case "ShipCountry":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.ShipCountry).ToList();
                        else
                            data = data.OrderBy(x => x.ShipCountry).ToList();
                        break;
                }
            }
            if (filter != null)
            {
                var newfiltersplits = filter;
                var filtersplits = newfiltersplits.Split('(', ')', ' ');
                var filterfield = filtersplits[1];
                var filtervalue = filtersplits[3];
                if (filtersplits.Length != 5)
                {
                    filterfield = filter.Split('(', ')', '\'')[3];
                    filtervalue = filter.Split('(', ')', '\'')[5];
                }
                switch (filterfield)
                {
                    case "OrderID":

                        Datae = (from cust in data
                                 where cust.OrderID.ToString() == filtervalue.ToString()
                                 select cust).ToList();
                        break;
                    case "EmployeeID":

                        Datae = (from cust in data
                                 where cust.EmployeeID.ToString() == filtervalue.ToString()
                                 select cust).ToList();
                        break;
                    case "Freight":

                        Datae = (from cust in data
                                 where cust.Freight.ToString() == filtervalue.ToString()
                                 select cust).ToList();
                        break;
                    case "CustomerID":
                        Datae = (from cust in data
                                 where cust.CustomerID.ToLower().StartsWith(filtervalue.ToString())
                                 select cust).ToList();
                        break;
                    case "ShipCity":
                        Datae = (from cust in data
                                 where cust.ShipCity.ToLower().StartsWith(filtervalue.ToString())
                                 select cust).ToList();
                        break;
                    case "ShipCountry":
                        Datae = (from cust in data
                                 where cust.ShipCountry.ToLower().StartsWith(filtervalue.ToString())
                                 select cust).ToList();
                        break;
                }
                Datase.AddRange(Datae);
               // count = Datase.Count;
                data = Datase;
            }
            return new
            {
                Items = data.Skip(skip).Take(take),
                Count = data.Count()
                //  return order;
            };
        }
        // GET: api/Order/5
       // [HttpGet("{id}", Name = "Get")]
        public object Get(int id)
        {
            var queryString = System.Web.HttpContext.Current.Request.QueryString;
            var dataa = Convert.ToString(queryString["id"]);
            var data = OrdersDetails.GetAllRecords().Where(user => user.CustomerID == dataa).ToList();
            return new { Items = data, Count = data.Count() };
        }

        // POST: api/Order
       [HttpPost]
        public object Post([FromBody]OrdersDetails value)
        {
            OrdersDetails.GetAllRecords().Add(value);
            var Data = OrdersDetails.GetAllRecords().ToList();
            int count = Data.Count();
            return Json(new { result = Data, count = count });
        }

        // PUT: api/Order/5
        [HttpPut]
        public object Put([FromBody]OrdersDetails value)
        {
            var ord = value;
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.EmployeeID = ord.EmployeeID;
            val.CustomerID = ord.CustomerID;
            val.Freight = ord.Freight;
            val.OrderDate = ord.OrderDate;
            val.ShipCity = ord.ShipCity;
            return value;
        }

        // DELETE: api/Order/5
        public object Delete(int id)
        {
            OrdersDetails.GetAllRecords().Remove(OrdersDetails.GetAllRecords().Where(or => or.OrderID == id).FirstOrDefault());
            return Json(id);
        }
    }
}
