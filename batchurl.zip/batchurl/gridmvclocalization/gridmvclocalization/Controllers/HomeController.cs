﻿using gridmvclocalization.Models;
using Syncfusion.EJ2.Base;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gridmvclocalization.Controllers
{
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = new List<OrdersDetails>();
        public static List<Employee1Details> empdata = new List<Employee1Details>();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Child()
        {
            return View();
        }
        public void BindData()
        {
            int code = 10000;
            for (int i = 1; i < 2; i++)
            {
                orddata.Add(new OrdersDetails(code + 2, "ANATR", i + 0, 3.3 * i, true, false, true, new DateTime(1995, 7, 2, 2, 3, 5), "Madrid", "Queen Cozinha", "Brazil", new DateTime(1996, 9, 11), "Avda. Azteca 123"));
                orddata.Add(new OrdersDetails(code + 3, "ANTON", i + 1, 4.3 * i, true, true, false, new DateTime(2012, 12, 25, 2, 3, 5), "Cholchester", "Frankenversand", "Germany", new DateTime(1996, 10, 7), "Carrera 52 con Ave. Bolívar #65-98 Llano Largo"));
                orddata.Add(new OrdersDetails(code + 4, "BLONP", i + 2, 5.3 * i, false, false, true, new DateTime(2002, 12, 25, 2, 3, 5), "Marseille", "Ernst Handel", "Austria", new DateTime(1996, 12, 30), "Magazinweg 7"));
                orddata.Add(new OrdersDetails(code + 5, "BOLID", i + 3, 6.3 * i, true, true, false, new DateTime(1953, 02, 18, 05, 2, 4), "Tsawassen", "Hanari Carnes", "Switzerland", new DateTime(1997, 12, 3), "1029 - 12th Ave. S."));
            }
        }
        public void ChildBindData()
        {
            for (int i = 1; i < 2; i++)
            {
                empdata.Add(new Employee1Details(i + 0, "Nancy", "Davolio", i + 0));
                empdata.Add(new Employee1Details(i + 1, "Andrew", "Fuller", i + 3));
                empdata.Add(new Employee1Details(i + 2, "Janet", "Leverling", i + 2));
                empdata.Add(new Employee1Details(i + 3, "Margaret", "Peacock", i + 1));

            }
        }

        public ActionResult UrlDatasource(DataManagerRequest dm)
        {
            ICollection<OrdersDetails> ordcol = orddata.ToList();
            if(ordcol.Count == 0)
            {
                BindData();
            }
            IEnumerable<OrdersDetails> DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
        public ActionResult BatchUpdate(string action, CRUDModel batchmodel)
        {
            if (batchmodel.Changed != null)
            {
                for (var i = 0; i < batchmodel.Changed.Count(); i++)
                {
                    var ord = batchmodel.Changed[i];
                    OrdersDetails val = orddata.Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
                    val.OrderID = ord.OrderID;
                    val.EmployeeID = ord.EmployeeID;
                    val.CustomerID = ord.CustomerID;
                }
            }

            if (batchmodel.Deleted != null)
            {
                for (var i = 0; i < batchmodel.Deleted.Count(); i++)
                {
                    orddata.Remove(orddata.Where(or => or.OrderID == batchmodel.Deleted[i].OrderID).FirstOrDefault());
                }
            }

            if (batchmodel.Added != null)
            {
                for (var i = 0; i < batchmodel.Added.Count(); i++)
                {
                    orddata.Insert(0, batchmodel.Added[i]);
                }
            }
            var data = orddata.ToList();
            return Json(data);

        }
        public ActionResult ChildDatasource(DataManagerRequest dm)
        {
            ICollection<Employee1Details> empcol = empdata.ToList();
            if (empcol.Count == 0)
            {
                ChildBindData();
            }
            IEnumerable<Employee1Details> DataSource = empdata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<Employee1Details>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);

        }

        public ActionResult ChildBatchUpdate(string action, CRUDModel2 batchmodel)
        {
            if (batchmodel.Changed != null)
            {
                for (var i = 0; i < batchmodel.Changed.Count(); i++)
                {
                    var emp = batchmodel.Changed[i];
                    Employee1Details val = empdata.Where(or => or.EmployeeID == emp.EmployeeID).FirstOrDefault();
                    val.FirstName = emp.FirstName;
                    val.EmployeeID = emp.EmployeeID;
                    val.LastName = emp.LastName;
                }
            }

            if (batchmodel.Deleted != null)
            {
                for (var i = 0; i < batchmodel.Deleted.Count(); i++)
                {
                    empdata.Remove(empdata.Where(or => or.EmployeeID == batchmodel.Deleted[i].EmployeeID).FirstOrDefault());
                }
            }

            if (batchmodel.Added != null)
            {
                for (var i = 0; i < batchmodel.Added.Count(); i++)
                {
                    empdata.Insert(0, batchmodel.Added[i]);
                }
            }
            var data = empdata.ToList();
            return Json(data);

        }
        public class CRUDModel
        {
            public List<OrdersDetails> Added { get; set; }
            public List<OrdersDetails> Changed { get; set; }
            public List<OrdersDetails> Deleted { get; set; }
            public OrdersDetails Value { get; set; }
            public int key { get; set; }
            public string action { get; set; }
        }
        public class CRUDModel2
        {
            public List<Employee1Details> Added { get; set; }
            public List<Employee1Details> Changed { get; set; }
            public List<Employee1Details> Deleted { get; set; }
            public Employee1Details Value { get; set; }
            public int key { get; set; }
            public string action { get; set; }
        }


        public class OrdersDetails
        {
            public OrdersDetails()
            {

            }
            public OrdersDetails(int OrderID, string CustomerId, int EmployeeId, double Freight, bool CanView, bool CanEdit, bool Active, DateTime OrderDate, string ShipCity, string ShipName, string ShipCountry, DateTime ShippedDate, string ShipAddress)
            {
                this.OrderID = OrderID;
                this.CustomerID = CustomerId;
                this.EmployeeID = EmployeeId;
                this.Freight = Freight;
                this.ShipCity = ShipCity;
                this.CanView = CanView;
                this.CanEdit = CanEdit;
                this.Active = Active;
                this.OrderDate = OrderDate;
                this.ShipName = ShipName;
                this.ShipCountry = ShipCountry;
                this.ShippedDate = ShippedDate;
                this.ShipAddress = ShipAddress;
            }

            public int? OrderID { get; set; }
            public string CustomerID { get; set; }
            public int? EmployeeID { get; set; }
            public double? Freight { get; set; }
            public string ShipCity { get; set; }
            public bool CanView { get; set; }
            public bool CanEdit { get; set; }
            public bool Active { get; set; }
            public DateTime OrderDate { get; set; }

            public string ShipName { get; set; }

            public string ShipCountry { get; set; }

            public DateTime ShippedDate { get; set; }
            public string ShipAddress { get; set; }
        }
        public class Employee1Details
        {
            public static List<Employee1Details> order = new List<Employee1Details>();
            public Employee1Details()
            {

            }
            public Employee1Details(int EmployeeId, string FirstName, string LastName, int ReportsTO)
            {
                this.EmployeeID = EmployeeId;
                this.FirstName = FirstName;
                this.LastName = LastName;
                this.ReportsTo = ReportsTo;
            }


            public int? EmployeeID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int? ReportsTo { get; set; }
        }
    }
}